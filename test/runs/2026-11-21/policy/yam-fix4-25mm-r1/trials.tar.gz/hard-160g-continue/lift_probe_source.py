"""Phase B settings in SI units; height is the observed exterior height."""
from math import sqrt

CAMERA_OFFSET = (0., -.60, .65)
# Camera-to-world columns: right, down, forward.
CAMERA_ROTATION = ((1., 0., 0.), (0., -sqrt(.5), sqrt(.5)), (0., -sqrt(.5), -sqrt(.5)))


def probe_height(height):
    return (.90 * height).clamp(.040, .100)
