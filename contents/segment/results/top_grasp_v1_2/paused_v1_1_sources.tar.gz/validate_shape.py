"""Staged v1.1 acceptance. Run formal commands under flock; output directories are immutable."""
from __future__ import annotations
import argparse
from dataclasses import replace
import hashlib
import json
from multiprocessing import Pool
from pathlib import Path
import sys
import time
import unittest

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('action', choices=('geometry', 'responses', 'observation'))
parser.add_argument('--run-id', required=True)
parser.add_argument('--reference-root', type=Path)
parser.add_argument('--workers', type=int, default=6)
parser.add_argument('--shapes', nargs='+', choices=('box','cylinder','ellipsoid'), default=['box'])
args = parser.parse_args()
if args.reference_root:
    # Load the archived v1 implementation in this fresh process, without altering the live checkout.
    sys.path.insert(0, str(args.reference_root.resolve()/'contents/segment'))

import mujoco
import numpy as np
import freeze_v1 as F
from model import ANCHORS, build, TABLE_PATH
from mj_adapter import OMEGA_MAX, SOLVER
from protocols import r1, r2, r3

SHAPES = {'box': (12.,12.), 'cylinder': (2.,12.), 'ellipsoid': (2.,2.)}


def response(job):
    category, test, shape = job
    k = ANCHORS[category]
    if not args.reference_root:
        k = replace(k, shape_p=SHAPES[shape][0], shape_q=SHAPES[shape][1])
    started = time.perf_counter()
    desc = build(k, omega_max=OMEGA_MAX)
    result = (r1(k, test[-1], desc=desc) if test.startswith('r1') else
              r2(k, 'edge', desc=desc) if test=='r2' else r3(k, desc=desc))
    return {'category':category, 'shape':shape, 'test':test, 'kappa':k.to_dict(),
            'internal':desc.internal, 'segments':len(desc.segments), 'result':result,
            'wall_s':time.perf_counter()-started}


def main():
    out = ROOT/'results/shape_v1_1'/args.run_id
    out.mkdir(parents=True, exist_ok=False)
    F.save(out/'manifest.json', {'source_sha256':F.hashes(), 'solver':SOLVER,
        'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'reference_root':str(args.reference_root), 'mujoco_version':mujoco.__version__,
        'table':str(TABLE_PATH), 'table_sha256':hashlib.sha256(TABLE_PATH.read_bytes()).hexdigest(),
        'shapes':args.shapes, 'action':args.action})
    if args.action=='geometry':
        suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'))
        result=unittest.TextTestRunner(verbosity=2).run(suite)
        records=sys.modules['test_shape_geometry'].ShapeGeometryTest.measurements
        F.save(out/'summary.json', {'tests_run':result.testsRun,'failures':len(result.failures),
            'errors':len(result.errors),'passed':result.wasSuccessful(),'v1_geometry':records})
        if not result.wasSuccessful():
            raise SystemExit(1)
    elif args.action=='observation':
        from shape_observation import render_depth
        rows=[]
        for shape,(p,q) in SHAPES.items():
            k=replace(ANCHORS['hard'],shape_p=p,shape_q=q)
            depth, features=render_depth(k)
            np.save(out/f'{shape}_depth.npy',depth)
            rows.append({'shape':shape,'features':features,'kappa':k.to_dict()})
        F.save(out/'summary.json',{'rows':rows,'preprocessing':'3x3 median; 10% oriented-box edge band'})
        print(rows,flush=True)
    else:
        jobs=[(category,test,shape) for category in ANCHORS for shape in args.shapes
              for test in ('r1y','r1z','r2','r3')]
        rows=[]
        with Pool(args.workers) as pool:
            for row in pool.imap_unordered(response,jobs):
                rows.append(row)
                F.save(out/f"{row['category']}_{row['shape']}_{row['test']}.json",row)
                print(row['category'],row['shape'],row['test'],'fail',row['result']['fail'],flush=True)
        F.save(out/'summary.json',{'rows':rows})


if __name__=='__main__':
    main()
