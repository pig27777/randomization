"""V1 geometry checks against MuJoCo's independent convex-mesh mass integrator."""
import itertools
import unittest
from dataclasses import replace

import mujoco
import numpy as np

from model import ANCHORS, build
from mj_adapter import OMEGA_MAX, Sim, scene
from sampling import check_kappa, sample_kappa, sample_rj
from shape_observation import depth_features


def aggregate(desc):
    mass = sum(s.mass for s in desc.segments)
    center = sum(s.mass*(s.pos+s.com) for s in desc.segments)/mass
    inertia = np.zeros((3, 3))
    for s in desc.segments:
        r = s.pos+s.com-center
        inertia += s.inertia_tensor+s.mass*(np.dot(r, r)*np.eye(3)-np.outer(r, r))
    return mass, center, inertia


def native_reference(desc):
    parts = []
    geoms = []
    for i, s in enumerate(desc.segments):
        vertex = ' '.join(f'{x:.17g}' for x in (s.vertices+s.pos).ravel())
        face = ' '.join(map(str, s.faces.ravel()))
        parts.append(f'<mesh name="m{i}" inertia="convex" vertex="{vertex}" face="{face}"/>')
        geoms.append(f'<geom type="mesh" mesh="m{i}" mass="{s.mass:.17g}"/>')
    model = mujoco.MjModel.from_xml_string('<mujoco><asset>'+''.join(parts)+'</asset><worldbody><body name="reference">'
        '<freejoint/>'+''.join(geoms)+'</body></worldbody></mujoco>')
    body = model.body('reference').id
    rotation = np.zeros(9)
    mujoco.mju_quat2Mat(rotation, model.body_iquat[body]);rotation=rotation.reshape(3, 3)
    return model.body_mass[body], model.body_ipos[body], rotation@np.diag(model.body_inertia[body])@rotation.T


class ShapeGeometryTest(unittest.TestCase):
    measurements = []
    def test_v1_mass_inertia_and_removed_connections(self):
        for category in ('hard', 'compressible'):
            for p, q in itertools.product((2., 5., 12.), repeat=2):
                with self.subTest(category=category, p=p, q=q):
                    k = replace(ANCHORS[category], shape_p=p, shape_q=q)
                    desc = build(k, omega_max=OMEGA_MAX)
                    mass, center, inertia = aggregate(desc)
                    reference_mass, reference_com, reference_inertia = native_reference(desc)
                    type(self).measurements.append(dict(category=category, p=p, q=q, mass=mass,
                        mass_error=abs(mass-k.mass), com_error=float(np.linalg.norm((center-reference_com)/np.array(k.size))),
                        inertia_relative_error=float(np.linalg.norm(inertia-reference_inertia)/np.linalg.norm(reference_inertia)),
                        retained_segments=len(desc.segments), removed_segments=int(np.prod(k.segments))-len(desc.segments),
                        joints=len(desc.joints)))
                    self.assertLess(abs(mass-k.mass), 1e-6)
                    self.assertLess(abs(mass-reference_mass), 1e-6)
                    self.assertLess(np.linalg.norm((center-reference_com)/np.array(k.size)), 1e-3)
                    self.assertLess(np.linalg.norm(inertia-reference_inertia)/np.linalg.norm(reference_inertia), 1e-3)
                    retained = {s.idx for s in desc.segments}
                    cell_volume = np.prod(k.size)/np.prod(k.segments)
                    self.assertTrue(all(s.volume >= .1*cell_volume-1e-14 for s in desc.segments))
                    expected = {(s.idx, tuple(s.idx[a]+int(a==axis) for a in range(3)))
                                for s in desc.segments for axis in range(3)
                                if tuple(s.idx[a]+int(a==axis) for a in range(3)) in retained}
                    actual = {(desc.segments[j.a].idx, desc.segments[j.b].idx) for j in desc.joints}
                    self.assertEqual(actual, expected)
                    sim = Sim(scene(desc, (0, 0, .5), table=False))
                    self.assertEqual(sim.m.nmesh, len(desc.segments))

    def test_requested_com_and_positive_inertia(self):
        for category in ('hard', 'compressible'):
            k = replace(ANCHORS[category], shape_p=2, shape_q=2, com_offset=(.12, -.1, .13))
            desc = build(k, omega_max=OMEGA_MAX)
            mass, center, inertia = aggregate(desc)
            np.testing.assert_allclose(center, np.array(k.size)*k.com_offset, atol=1e-9)
            self.assertTrue(all(np.linalg.eigvalsh(s.inertia_tensor).min()>0 for s in desc.segments))
            self.assertGreater(np.linalg.eigvalsh(inertia).min(), 0)

    def test_shape_sampler_pairing_and_boundaries(self):
        for cat in ('hard','bendable','compressible'):
            for seed in range(3):
                k = sample_kappa(np.random.default_rng(seed), cat)
                rj = sample_rj(np.random.default_rng(seed), cat)
                self.assertEqual(k, rj.kappa)
                self.assertTrue(2 <= k.shape_p <= 12 and 2 <= k.shape_q <= 12)
                desc = build(k, omega_max=OMEGA_MAX)
                for a, b in zip(desc.segments, rj.segments):
                    np.testing.assert_array_equal(a.vertices, b.vertices)
                    np.testing.assert_array_equal(a.inertia_tensor, b.inertia_tensor)
        for value in (1.99, 12.01, float('nan')):
            self.assertTrue(check_kappa(replace(ANCHORS['bendable'], shape_p=value)))

    def test_depth_features_reject_isolated_spikes(self):
        height = np.zeros((100, 100))
        height[20:80, 10:90] = .1
        height[10, 10] = .8
        feature = depth_features(1-height, 1)
        self.assertAlmostEqual(feature['maximum_height_m'], .1)
        self.assertGreater(feature['footprint_fill_ratio'], .99)
        self.assertAlmostEqual(feature['edge_height_ratio'], 1.)


if __name__ == '__main__':
    unittest.main()
