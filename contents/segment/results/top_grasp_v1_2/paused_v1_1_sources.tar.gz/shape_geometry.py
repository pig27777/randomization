"""Convex superquadric envelope, cell clipping and volume-based mass integration.

MuJoCo's existing hull compiler triangulates the sampled envelope; no extra package is needed.
Clipping preserves convexity. Positive tetrahedra partition each clipped cell, supporting both
uniform density and a smooth positive density bias for kappa's requested whole-object COM.
"""
from dataclasses import dataclass
from functools import lru_cache
import math

import numpy as np

EPS = 1e-11
MIN_CELL_FRACTION = .1


def shape_factors(p, q):
    """Analytic volume and z-second-moment fractions relative to the bounding box."""
    def gamma_ratio(a, b, c):
        return math.exp(math.lgamma(a) + math.lgamma(b) - math.lgamma(c))
    volume = gamma_ratio(1 + 1/p, 1 + 1/p, 1 + 2/p) * gamma_ratio(1 + 1/q, 1 + 2/q, 1 + 3/q)
    second_z = gamma_ratio(1 + 1/p, 1 + 3/p, 1 + 4/p) * gamma_ratio(1 + 1/q, 1 + 4/q, 1 + 5/q)
    return volume, second_z


def _text(a):
    return " ".join(f"{x:.17g}" for x in np.asarray(a).ravel())


def _hull(vertices):
    import mujoco
    xml = ('<mujoco><asset><mesh name="envelope" inertia="convex" vertex="' + _text(vertices) +
           '"/></asset><worldbody><body><freejoint/><geom type="mesh" mesh="envelope" mass="1"/>'
           '</body></worldbody></mujoco>')
    m = mujoco.MjModel.from_xml_string(xml)
    rotation = np.zeros(9)
    mujoco.mju_quat2Mat(rotation, m.mesh_quat[0])
    vertices = m.mesh_vert.astype(float) @ rotation.reshape(3, 3).T + m.mesh_pos[0]
    center = vertices.mean(0)
    faces = []
    for triangle in m.mesh_face:
        f = vertices[triangle].copy()
        if np.dot(np.cross(f[1]-f[0], f[2]-f[0]), f.mean(0)-center) < 0:
            f = f[::-1]
        faces.append(f)
    return faces


@lru_cache(maxsize=64)
def envelope(p, q):
    if not (2 <= p <= 12 and 2 <= q <= 12):
        raise ValueError("shape_p and shape_q must be in [2, 12]")
    u = np.linspace(0, math.pi, 25)[1:-1, None]
    v = np.linspace(0, 2*math.pi, 48, endpoint=False)[None, :]
    power = lambda x, a: np.sign(x) * np.abs(x)**a
    x = np.broadcast_to(.5*power(np.cos(u), 2/q), (23, 48))
    r = np.sin(u)**(2/q)
    y = .5*r*power(np.cos(v), 2/p)
    z = .5*r*power(np.sin(v), 2/p)
    points = np.c_[x.ravel(), y.ravel(), z.ravel()]
    return _hull(np.vstack((points, [-.5, 0, 0], [.5, 0, 0])))


def clip(faces, axis, bound, sign):
    """Intersect a closed convex polyhedron with sign*x[axis] <= sign*bound."""
    out, cuts = [], []
    for face in faces:
        d = sign * (face[:, axis] - bound)
        if np.max(d) <= EPS:
            out.append(face)
            continue
        if np.min(d) > EPS:
            continue
        polygon = []
        for i, a in enumerate(face):
            b, da, db = face[(i+1) % len(face)], d[i], d[(i+1) % len(face)]
            if da <= EPS:
                polygon.append(a)
            if (da < -EPS and db > EPS) or (da > EPS and db < -EPS):
                crossing = a + da/(da-db)*(b-a)
                crossing[axis] = bound
                polygon.append(crossing)
                cuts.append(crossing)
            elif abs(da) <= EPS:
                cuts.append(a)
        if len(polygon) >= 3:
            out.append(np.array(polygon))
    if cuts:
        cap = np.unique(np.round(cuts, 11), axis=0)
        if len(cap) >= 3:
            n = np.eye(3)[axis]*sign
            u = np.eye(3)[(axis+1) % 3]
            v = np.cross(n, u)
            delta = cap-cap.mean(0)
            out.append(cap[np.argsort(np.arctan2(delta@v, delta@u))])
    return out


@dataclass
class Cell:
    idx: tuple
    center: np.ndarray
    faces: list
    vertices: np.ndarray
    triangles: np.ndarray
    volumes: np.ndarray
    centroids: np.ndarray
    seconds: np.ndarray

    @property
    def volume(self):
        return float(self.volumes.sum())

    def section(self, axis, bound):
        """Area and transverse second moments of a cell face, in unit-box coordinates."""
        area = 0.
        moments = np.zeros(3)
        for face in self.faces:
            if not np.all(np.abs(face[:, axis]-bound) < 1e-9):
                continue
            for i in range(1, len(face)-1):
                tri = face[[0, i, i+1]]
                a = .5*np.linalg.norm(np.cross(tri[1]-tri[0], tri[2]-tri[0]))
                t = tri-self.center
                area += a
                moments += a*(np.sum(t*t, axis=0) + np.sum(t, axis=0)**2)/12
        return area, moments


def _cell(idx, center, faces):
    if not faces:
        return None
    vertices = np.unique(np.round(np.concatenate(faces), 11), axis=0)
    if len(vertices) < 4:
        return None
    inner = vertices.mean(0)
    triangles, tetrahedra = [], []
    index = {tuple(v): i for i, v in enumerate(vertices)}
    for face in faces:
        for i in range(1, len(face)-1):
            tri = np.round(face[[0, i, i+1]], 11)
            if np.linalg.norm(np.cross(tri[1]-tri[0], tri[2]-tri[0])) < 1e-14:
                continue
            if np.dot(np.cross(tri[1]-tri[0], tri[2]-tri[0]), tri.mean(0)-inner) < 0:
                tri = tri[::-1]
            triangles.append([index[tuple(v)] for v in tri])
            tetrahedra.append(np.vstack((inner, tri)))
    if not tetrahedra:
        return None
    t = np.array(tetrahedra)
    volume = np.abs(np.linalg.det(t[:, 1:]-t[:, :1]))/6
    sums = t.sum(1)
    seconds = (np.einsum('nvi,nvj->nij', t, t) + np.einsum('ni,nj->nij', sums, sums))/20
    return Cell(idx, center, faces, vertices, np.array(triangles), volume, t.mean(1), seconds)


@lru_cache(maxsize=128)
def cells(segments, p, q):
    segments = tuple(segments)
    parts = {(): envelope(p, q)}
    for axis, n in enumerate(segments):
        split = {}
        for previous, faces in parts.items():
            for i in range(n):
                piece = clip(faces, axis, -.5+i/n, -1)
                piece = clip(piece, axis, -.5+(i+1)/n, 1)
                if piece:
                    split[previous+(i,)] = piece
        parts = split
    volume_cell = 1/np.prod(segments)
    retained = []
    for idx, faces in parts.items():
        center = (np.array(idx)+.5)/np.array(segments)-.5
        cell = _cell(idx, center, faces)
        if cell is not None and cell.volume >= MIN_CELL_FRACTION*volume_cell:
            retained.append(cell)
    if not retained:
        raise ValueError("shape has no retained cells")
    return tuple(retained)


def mass_properties(parts, size, mass, offset):
    """Integrate piecewise constant positive density over the actual clipped tetrahedra.

    Uniform density when offset=0. Otherwise exponential weights at tetrahedron centroids are
    solved to match the requested COM. Inertia still integrates the full tetrahedron volumes,
    rather than treating tetrahedra as point masses.
    """
    volumes = np.concatenate([c.volumes for c in parts])
    centers = np.concatenate([c.centroids for c in parts])
    seconds = np.concatenate([c.seconds for c in parts])
    target = np.array(offset)
    alpha = np.zeros(3)
    for _ in range(50):
        logw = np.log(np.maximum(volumes, 1e-300)) + centers@alpha
        w = np.exp(logw-logw.max());w /= w.sum()
        com = w@centers
        delta = target-com
        if np.max(np.abs(delta)) < 1e-11:
            break
        z = centers-com
        covariance = np.einsum('n,ni,nj->ij', w, z, z)
        step = np.linalg.solve(covariance, delta)
        alpha += step/max(1., np.linalg.norm(step)/5)
    else:
        raise ValueError(f"COM offset {offset} cannot be realized inside the retained shape")
    size = np.asarray(size)
    properties = []
    start = 0
    for cell in parts:
        stop = start+len(cell.volumes)
        weights = w[start:stop]
        fraction = weights.sum()
        com = weights@centers[start:stop]/fraction
        second = np.einsum('n,nij->ij', weights, seconds[start:stop])/fraction
        covariance = (second-np.outer(com, com))*np.outer(size, size)
        m = mass*fraction
        inertia = m*(np.trace(covariance)*np.eye(3)-covariance)
        properties.append((float(m), (com-cell.center)*size, inertia))
        start = stop
    return properties
