"""The two shape observations, computed solely from a top-view depth image."""
import numpy as np


def depth_features(depth, camera_height, edge_fraction=.1):
    """Orthographic, vertically downward camera above a table at z=0.

    The edge band is the outer 10% on either side of the image-derived oriented box.
    No stiffness, mass or shape parameter enters these observations.
    """
    depth = np.asarray(depth, float)
    if depth.ndim != 2 or not np.all(np.isfinite(depth)):
        raise ValueError("expected a finite 2D top-view depth image")
    height = camera_height-depth
    # Edge-on mesh triangles can leave isolated rasterization depth spikes. A local median uses
    # only the observed image, preserving the same preprocessing for simulation and real depth.
    windows = np.lib.stride_tricks.sliding_window_view(np.pad(height, 1, mode="edge"), (3, 3))
    height = np.median(windows, axis=(-2, -1))
    maximum = float(height.max())
    if maximum <= 1e-4:
        raise ValueError("depth image contains no object above the table")
    mask = height > max(1e-4, .005*maximum)
    yy, xx = np.nonzero(mask)
    xy = np.c_[xx, yy].astype(float)
    centered = xy-xy.mean(0)
    _, axes = np.linalg.eigh(centered.T@centered)
    coordinates = centered@axes
    lo, hi = coordinates.min(0)-.5, coordinates.max(0)+.5
    span = hi-lo
    relative = np.minimum(coordinates-lo, hi-coordinates)/span
    edge = np.any(relative < edge_fraction, axis=1)
    return {"footprint_fill_ratio": float(len(xy)/np.prod(span)),
            "edge_height_ratio": float(height[yy[edge], xx[edge]].mean()/maximum),
            "maximum_height_m": maximum, "foreground_pixels": int(len(xy)),
            "edge_fraction": edge_fraction}


def render_depth(kappa, pixels=256):
    """Render the actual collision geometry; call under the formal GPU lock for acceptance."""
    import mujoco
    from model import build
    from mj_adapter import OMEGA_MAX, Sim, scene
    desc = build(kappa, omega_max=OMEGA_MAX)
    camera_height = max(1., 3*kappa.size[2])
    extent = 1.15*max(kappa.size[:2])
    camera = (f'<camera name="top_depth" pos="0 0 {camera_height}" '
              f'projection="orthographic" fovy="{extent}"/>')
    sim = Sim(scene(desc, (0, 0, kappa.size[2]/2), worldbody=camera))
    with mujoco.Renderer(sim.m, height=pixels, width=pixels) as renderer:
        renderer.enable_depth_rendering()
        renderer.update_scene(sim.d, camera="top_depth")
        depth = renderer.render().copy()
    return depth, depth_features(depth, camera_height)
